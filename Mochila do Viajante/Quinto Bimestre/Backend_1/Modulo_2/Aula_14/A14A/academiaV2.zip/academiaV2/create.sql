
create table IF NOT EXISTS ESTUDANTES(
id varchar(255), NOME varchar(255), SOBRENOME varchar(255));