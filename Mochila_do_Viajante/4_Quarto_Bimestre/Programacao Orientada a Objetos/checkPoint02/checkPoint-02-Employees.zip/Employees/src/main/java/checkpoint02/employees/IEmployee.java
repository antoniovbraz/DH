package checkpoint02.employees;

public interface IEmployee {
    int getSalary();
}
